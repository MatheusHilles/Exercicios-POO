
package unidade01;

public class App {
    
    public static void main(String[] args ) {
        
        Cachorro dog1;
        
        dog1 = new Cachorro();
        
        dog1.nome = "Pingo";
        dog1.raca = "Labrador";
        dog1.cor = "Branco";
        dog1.peso = 12.0;
        
        Cachorro dog2 = new Cachorro();
        
        dog2.nome = "Brutos";
        dog2.raca = "Pastor Alemão";
        dog2.cor = "Marrom";
        dog2.peso = 21.0;
        
        System.out.println("Informações do dog 1");
        System.out.println("Nome: " + dog1.nome);
        System.out.println("Raça: " + dog1.raca);
        System.out.println("Cor: " + dog1.cor);
        System.out.println("Peso: " + dog1.peso);
        
        dog1.peso = dog1.peso + 2;
        System.out.println("Nome: " + dog1.nome);
        System.out.println("Peso: " + dog1.peso);
        
        
    }
    
}
